module.exports = {
  name: "",
  aliases: [""],
  permission: 4,

  async execute(client, message) {},
};
